import { TestBed } from '@angular/core/testing';

import { DataStreamService } from './dummy-data.service';

describe('DummyDataService', () => {
  let service: DataStreamService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DataStreamService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
